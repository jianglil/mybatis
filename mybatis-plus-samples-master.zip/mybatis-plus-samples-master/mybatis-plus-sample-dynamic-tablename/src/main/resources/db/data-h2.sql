DELETE FROM user_2018;

INSERT INTO user_2018 (id, name, age, email) VALUES
(1, 'Jone', 18, 'test1@baomidou.com');

DELETE FROM user_2019;

INSERT INTO user_2019 (id, name, age, email) VALUES
(1, 'Jack', 20, 'test2@baomidou.com');