package com.baomidou.mybatisplus.samples.wrapper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.samples.wrapper.entity.Role;

/**
 * @author miemie
 * @since 2018-08-10
 */
public interface RoleMapper extends BaseMapper<Role> {
}
