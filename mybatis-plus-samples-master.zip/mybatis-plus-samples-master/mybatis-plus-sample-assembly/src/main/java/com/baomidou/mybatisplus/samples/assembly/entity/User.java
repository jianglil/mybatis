package com.baomidou.mybatisplus.samples.assembly.entity;

import lombok.Data;

/**
 * @author nieqiuqiu
 */
@Data
public class User {
    private Long id;
    private String name;
    private Integer age;
    private String email;
}
