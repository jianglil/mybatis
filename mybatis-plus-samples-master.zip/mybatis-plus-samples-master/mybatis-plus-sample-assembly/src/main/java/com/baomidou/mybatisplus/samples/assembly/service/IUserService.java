package com.baomidou.mybatisplus.samples.assembly.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.samples.assembly.entity.User;

/**
 * @author nieqiuqiu
 */
public interface IUserService extends IService<User> {

}
