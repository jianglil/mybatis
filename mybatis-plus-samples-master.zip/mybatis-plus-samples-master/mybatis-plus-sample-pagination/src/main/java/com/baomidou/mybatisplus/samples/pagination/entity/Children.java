package com.baomidou.mybatisplus.samples.pagination.entity;

import lombok.Data;

/**
 * @author miemie
 * @since 2019-06-12
 */
@Data
public class Children {
    private Long id;
    private String name;
    private Long userId;
}
